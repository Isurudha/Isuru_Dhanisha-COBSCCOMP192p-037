//
//  ViewController.swift
//  Isuru_Dhanisha-COBSCCOMP192p-037
//
//  Created by Isuru Dhanisha  on 2021-02-05.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

